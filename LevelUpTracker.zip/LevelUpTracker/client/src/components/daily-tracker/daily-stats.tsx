import { useFormContext } from "react-hook-form";
import { ChartLine, Pencil, Volume2, Dumbbell, Hourglass } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Rating } from "@/components/ui/rating";
import SectionHeader from "@/components/layout/section-header";
import { Card, CardContent } from "@/components/ui/card";
import type { DailyEntryForm } from "@shared/schema";

export default function DailyStats() {
  const { register, setValue, watch } = useFormContext<DailyEntryForm>();
  
  const skillStudied = watch("skillStudied");
  const mediaConsumed = watch("mediaConsumed");
  const physicalTraining = watch("physicalTraining");
  const deepWorkHours = watch("deepWorkHours");
  const growthRating = watch("growthRating");
  
  // Count completed fields
  const totalFields = 5;
  const completedFields = [
    !!skillStudied,
    !!mediaConsumed,
    !!physicalTraining,
    !!deepWorkHours,
    !!growthRating
  ].filter(Boolean).length;

  const handleRatingChange = (value: number) => {
    setValue("growthRating", value, { shouldValidate: true });
  };

  return (
    <Card>
      <CardContent className="p-5">
        <SectionHeader
          icon={ChartLine}
          title="Daily Stats"
          completed={completedFields}
          total={totalFields}
        />
        
        <div className="space-y-4">
          <div className="group">
            <Label htmlFor="skillStudied" className="flex items-center">
              <Pencil className="h-4 w-4 mr-2 text-gray-500 dark:text-gray-400" />
              Skill Studied:
            </Label>
            <Input
              id="skillStudied"
              placeholder="What skill did you work on today?"
              className="mt-1"
              {...register("skillStudied")}
            />
          </div>

          <div className="group">
            <Label htmlFor="mediaConsumed" className="flex items-center">
              <Volume2 className="h-4 w-4 mr-2 text-gray-500 dark:text-gray-400" />
              Podcast / Audiobook / Video:
            </Label>
            <Input
              id="mediaConsumed"
              placeholder="What did you listen to or watch today?"
              className="mt-1"
              {...register("mediaConsumed")}
            />
          </div>

          <div className="group">
            <Label htmlFor="physicalTraining" className="flex items-center">
              <Dumbbell className="h-4 w-4 mr-2 text-gray-500 dark:text-gray-400" />
              Physical Training:
            </Label>
            <Input
              id="physicalTraining"
              placeholder="What exercise did you do today?"
              className="mt-1"
              {...register("physicalTraining")}
            />
          </div>

          <div className="group">
            <Label htmlFor="deepWorkHours" className="flex items-center">
              <Hourglass className="h-4 w-4 mr-2 text-gray-500 dark:text-gray-400" />
              Hours of Deep Work:
            </Label>
            <Input
              id="deepWorkHours"
              type="number"
              min="0"
              max="24"
              step="0.5"
              placeholder="0"
              className="mt-1"
              {...register("deepWorkHours", { 
                valueAsNumber: true,
                min: 0,
                max: 24
              })}
            />
          </div>

          <div className="group">
            <Label className="flex items-center">
              <ChartLine className="h-4 w-4 mr-2 text-gray-500 dark:text-gray-400" />
              Today's Growth Rating (1-10):
            </Label>
            <div className="mt-1">
              <Rating 
                value={growthRating} 
                onChange={handleRatingChange} 
              />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
