import { useFormContext } from "react-hook-form";
import { Star } from "lucide-react";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import SectionHeader from "@/components/layout/section-header";
import { Card, CardContent } from "@/components/ui/card";
import type { DailyEntryForm } from "@shared/schema";

export default function DayReflection() {
  const { register, watch } = useFormContext<DailyEntryForm>();
  
  const wins = watch("reflection.wins");
  const growthAreas = watch("reflection.growthAreas");
  const lessonLearned = watch("reflection.lessonLearned");
  
  // Count completed fields
  const totalFields = 3;
  const completedFields = [
    !!wins,
    !!growthAreas,
    !!lessonLearned
  ].filter(Boolean).length;

  return (
    <Card>
      <CardContent className="p-5">
        <SectionHeader
          icon={Star}
          title="End of Day Reflection"
          completed={completedFields}
          total={totalFields}
        />
        
        <div className="space-y-4">
          <div className="group">
            <Label htmlFor="todayWin">
              What did I win today?
            </Label>
            <Textarea
              id="todayWin"
              placeholder="What victories did you achieve today?"
              className="mt-1"
              rows={2}
              {...register("reflection.wins")}
            />
          </div>

          <div className="group">
            <Label htmlFor="growthAreas">
              Where can I grow?
            </Label>
            <Textarea
              id="growthAreas"
              placeholder="What areas need improvement?"
              className="mt-1"
              rows={2}
              {...register("reflection.growthAreas")}
            />
          </div>

          <div className="group">
            <Label htmlFor="lessonLearned">
              One lesson learned:
            </Label>
            <Textarea
              id="lessonLearned"
              placeholder="What did you learn today?"
              className="mt-1"
              rows={2}
              {...register("reflection.lessonLearned")}
            />
          </div>

          <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg mt-4">
            <p className="text-center text-gray-700 dark:text-gray-300 italic text-sm">
              "To be better tomorrow than I was today—that's my mission."
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
