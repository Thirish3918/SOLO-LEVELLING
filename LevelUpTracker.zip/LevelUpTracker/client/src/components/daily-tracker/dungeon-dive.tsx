import { useFormContext } from "react-hook-form";
import { Moon } from "lucide-react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import SectionHeader from "@/components/layout/section-header";
import { Card, CardContent } from "@/components/ui/card";
import type { DailyEntryForm } from "@shared/schema";

export default function DungeonDive() {
  const { register, watch } = useFormContext<DailyEntryForm>();
  
  const startTime = watch("dungeonDive.startTime");
  const endTime = watch("dungeonDive.endTime");
  const outcome = watch("dungeonDive.outcome");
  
  // Count completed fields
  const totalFields = 3;
  const completedFields = [
    !!startTime,
    !!endTime,
    !!outcome
  ].filter(Boolean).length;

  return (
    <Card>
      <CardContent className="p-5">
        <SectionHeader
          icon={Moon}
          title="Dungeon Dive"
          subtitle="Solitude Focus"
          completed={completedFields}
          total={totalFields}
        />
        
        <div className="space-y-4">
          <div className="text-sm text-gray-700 dark:text-gray-300 font-medium mb-1">
            Focus Block (60-90 min solo deep work)
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="group">
              <Label htmlFor="startTime">
                Start Time:
              </Label>
              <Input
                id="startTime"
                type="time"
                className="mt-1"
                {...register("dungeonDive.startTime")}
              />
            </div>

            <div className="group">
              <Label htmlFor="endTime">
                End Time:
              </Label>
              <Input
                id="endTime"
                type="time"
                className="mt-1"
                {...register("dungeonDive.endTime")}
              />
            </div>
          </div>

          <div className="group">
            <Label htmlFor="focusOutcome">
              Outcome:
            </Label>
            <Textarea
              id="focusOutcome"
              placeholder="What did you achieve during this focus block?"
              className="mt-1"
              rows={2}
              {...register("dungeonDive.outcome")}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
