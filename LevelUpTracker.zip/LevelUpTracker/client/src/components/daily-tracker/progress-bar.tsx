import { useMemo } from "react";
import { Progress } from "@/components/ui/progress";

interface ProgressBarProps {
  sections: Array<{
    title: string;
    completedFields: number;
    totalFields: number;
  }>;
}

export default function ProgressBar({ sections }: ProgressBarProps) {
  const { totalSections, completedSections, progressPercentage } = useMemo(() => {
    // A section is considered complete when all fields are filled
    const completedSections = sections.filter(
      section => section.completedFields === section.totalFields && section.totalFields > 0
    ).length;
    
    const totalSections = sections.length;
    const progressPercentage = totalSections > 0 
      ? Math.round((completedSections / totalSections) * 100) 
      : 0;
    
    return { totalSections, completedSections, progressPercentage };
  }, [sections]);
  
  return (
    <div className="container mx-auto px-4 py-3">
      <Progress value={progressPercentage} className="h-2.5" />
      <div className="flex justify-between mt-1 text-xs text-gray-500 dark:text-gray-400">
        <span>{completedSections} sections complete</span>
        <span>{totalSections} total sections</span>
      </div>
    </div>
  );
}
