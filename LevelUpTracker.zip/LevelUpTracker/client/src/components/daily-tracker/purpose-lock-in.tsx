import { useFormContext } from "react-hook-form";
import { Gem } from "lucide-react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import SectionHeader from "@/components/layout/section-header";
import { Card, CardContent } from "@/components/ui/card";
import type { DailyEntryForm } from "@shared/schema";

export default function PurposeLockIn() {
  const { register, watch } = useFormContext<DailyEntryForm>();
  
  const whoFor = watch("purpose.whoFor");
  const myPurpose = watch("purpose.myPurpose");
  const todayReminder = watch("purpose.todayReminder");
  
  // Count completed fields
  const totalFields = 3;
  const completedFields = [
    !!whoFor,
    !!myPurpose,
    !!todayReminder
  ].filter(Boolean).length;

  return (
    <Card>
      <CardContent className="p-5">
        <SectionHeader
          icon={Gem}
          title="Purpose Lock-in"
          subtitle="Why I Grind"
          completed={completedFields}
          total={totalFields}
        />
        
        <div className="space-y-4">
          <div className="group">
            <Label htmlFor="whoFor">
              Who/What I'm Doing This For:
            </Label>
            <Input
              id="whoFor"
              placeholder="Who or what motivates you?"
              className="mt-1"
              {...register("purpose.whoFor")}
            />
          </div>

          <div className="group">
            <Label htmlFor="myPurpose">
              My Purpose:
            </Label>
            <Textarea
              id="myPurpose"
              placeholder="What's your deeper purpose?"
              className="mt-1"
              rows={2}
              {...register("purpose.myPurpose")}
            />
          </div>

          <div className="group">
            <Label htmlFor="todayReminder">
              Today's Reminder:
            </Label>
            <Textarea
              id="todayReminder"
              placeholder="What do you need to remember today?"
              className="mt-1"
              rows={2}
              {...register("purpose.todayReminder")}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
