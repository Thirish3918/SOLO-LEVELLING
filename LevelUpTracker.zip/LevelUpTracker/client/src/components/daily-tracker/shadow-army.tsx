import { useFormContext } from "react-hook-form";
import { Users } from "lucide-react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import SectionHeader from "@/components/layout/section-header";
import { Card, CardContent } from "@/components/ui/card";
import type { DailyEntryForm } from "@shared/schema";

export default function ShadowArmy() {
  const { register, setValue, watch } = useFormContext<DailyEntryForm>();
  
  const nameRole = watch("shadowArmy.nameRole");
  const purpose = watch("shadowArmy.purpose");
  const leadOrLearn = watch("shadowArmy.leadOrLearn");
  
  // Count completed fields
  const totalFields = 3;
  const completedFields = [
    !!nameRole,
    !!purpose,
    !!leadOrLearn
  ].filter(Boolean).length;

  const handleRadioChange = (value: string) => {
    setValue("shadowArmy.leadOrLearn", value, { shouldValidate: true });
  };

  return (
    <Card>
      <CardContent className="p-5">
        <SectionHeader
          icon={Users}
          title="Build My Shadow Army"
          subtitle="Leadership/Network"
          completed={completedFields}
          total={totalFields}
        />
        
        <div className="space-y-4">
          <div className="text-sm text-gray-700 dark:text-gray-300 font-medium mb-1">
            People I Connected With / Helped Today:
          </div>

          <div className="group">
            <Label htmlFor="nameRole">
              Name / Role:
            </Label>
            <Input
              id="nameRole"
              placeholder="Who did you connect with?"
              className="mt-1"
              {...register("shadowArmy.nameRole")}
            />
          </div>

          <div className="group">
            <Label htmlFor="connectionPurpose">
              Purpose of Connection:
            </Label>
            <Textarea
              id="connectionPurpose"
              placeholder="Why did you connect with this person?"
              className="mt-1"
              rows={2}
              {...register("shadowArmy.purpose")}
            />
          </div>

          <div className="group">
            <Label>
              Did I lead or learn?
            </Label>
            <RadioGroup 
              className="flex space-x-4 mt-1"
              value={leadOrLearn}
              onValueChange={handleRadioChange}
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="lead" id="lead" />
                <Label htmlFor="lead" className="cursor-pointer">Lead</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="learn" id="learn" />
                <Label htmlFor="learn" className="cursor-pointer">Learn</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="both" id="both" />
                <Label htmlFor="both" className="cursor-pointer">Both</Label>
              </div>
            </RadioGroup>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
