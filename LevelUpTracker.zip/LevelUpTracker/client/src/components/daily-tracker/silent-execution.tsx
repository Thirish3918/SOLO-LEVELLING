import { useFormContext } from "react-hook-form";
import { Brain } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import SectionHeader from "@/components/layout/section-header";
import { Card, CardContent } from "@/components/ui/card";
import type { DailyEntryForm } from "@shared/schema";

export default function SilentExecution() {
  const { register, setValue, watch } = useFormContext<DailyEntryForm>();
  
  const task1 = watch("silentExecution.task1");
  const task2 = watch("silentExecution.task2");
  const task3 = watch("silentExecution.task3");
  
  // Count completed fields: a task is complete when it has a description and is checked
  const totalFields = 3;
  const completedFields = [
    task1.description && task1.completed,
    task2.description && task2.completed,
    task3.description && task3.completed
  ].filter(Boolean).length;

  const handleCheckboxChange = (taskNumber: 1 | 2 | 3, checked: boolean) => {
    setValue(`silentExecution.task${taskNumber}.completed`, checked, { shouldValidate: true });
  };

  return (
    <Card>
      <CardContent className="p-5">
        <SectionHeader
          icon={Brain}
          title="Silent Execution"
          subtitle="Actions > Words"
          completed={completedFields}
          total={totalFields}
        />
        
        <div className="space-y-4">
          <div className="group">
            <div className="task-item bg-gray-50 dark:bg-gray-700 rounded-lg p-3 mb-3">
              <div className="flex items-start">
                <div className="flex-shrink-0 pt-0.5">
                  <Checkbox 
                    id="task1"
                    checked={task1.completed}
                    onCheckedChange={(checked) => handleCheckboxChange(1, checked as boolean)}
                    className="h-5 w-5"
                  />
                </div>
                <div className="ml-3 w-full">
                  <Input
                    placeholder="Task 1"
                    className="w-full bg-transparent border-0 border-b border-gray-200 dark:border-gray-600 p-0 pb-1 focus:ring-0 text-gray-900 dark:text-white text-sm h-7"
                    {...register("silentExecution.task1.description")}
                  />
                </div>
              </div>
            </div>
            
            <div className="task-item bg-gray-50 dark:bg-gray-700 rounded-lg p-3 mb-3">
              <div className="flex items-start">
                <div className="flex-shrink-0 pt-0.5">
                  <Checkbox 
                    id="task2"
                    checked={task2.completed}
                    onCheckedChange={(checked) => handleCheckboxChange(2, checked as boolean)}
                    className="h-5 w-5"
                  />
                </div>
                <div className="ml-3 w-full">
                  <Input
                    placeholder="Task 2"
                    className="w-full bg-transparent border-0 border-b border-gray-200 dark:border-gray-600 p-0 pb-1 focus:ring-0 text-gray-900 dark:text-white text-sm h-7"
                    {...register("silentExecution.task2.description")}
                  />
                </div>
              </div>
            </div>
            
            <div className="task-item bg-gray-50 dark:bg-gray-700 rounded-lg p-3">
              <div className="flex items-start">
                <div className="flex-shrink-0 pt-0.5">
                  <Checkbox 
                    id="task3"
                    checked={task3.completed}
                    onCheckedChange={(checked) => handleCheckboxChange(3, checked as boolean)}
                    className="h-5 w-5"
                  />
                </div>
                <div className="ml-3 w-full">
                  <Input
                    placeholder="Task 3"
                    className="w-full bg-transparent border-0 border-b border-gray-200 dark:border-gray-600 p-0 pb-1 focus:ring-0 text-gray-900 dark:text-white text-sm h-7"
                    {...register("silentExecution.task3.description")}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
