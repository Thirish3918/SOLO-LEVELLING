import { useFormContext } from "react-hook-form";
import { Bomb } from "lucide-react";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import SectionHeader from "@/components/layout/section-header";
import { Card, CardContent } from "@/components/ui/card";
import type { DailyEntryForm } from "@shared/schema";

export default function StoicMind() {
  const { register, watch } = useFormContext<DailyEntryForm>();
  
  const challenges = watch("stoicMind.challenges");
  const response = watch("stoicMind.response");
  const improvement = watch("stoicMind.improvement");
  
  // Count completed fields
  const totalFields = 3;
  const completedFields = [
    !!challenges,
    !!response,
    !!improvement
  ].filter(Boolean).length;

  return (
    <Card>
      <CardContent className="p-5">
        <SectionHeader
          icon={Bomb}
          title="Stoic Mind Training"
          subtitle="Emotional Control"
          completed={completedFields}
          total={totalFields}
        />
        
        <div className="space-y-4">
          <div className="text-sm text-gray-700 dark:text-gray-300 font-medium mb-1">
            Mind Check:
          </div>

          <div className="group">
            <Label htmlFor="threwOff">
              Did anything throw me off today?
            </Label>
            <Textarea
              id="threwOff"
              placeholder="What mental challenges did you face?"
              className="mt-1"
              rows={2}
              {...register("stoicMind.challenges")}
            />
          </div>

          <div className="group">
            <Label htmlFor="response">
              How did I respond?
            </Label>
            <Textarea
              id="response"
              placeholder="How did you handle these challenges?"
              className="mt-1"
              rows={2}
              {...register("stoicMind.response")}
            />
          </div>

          <div className="group">
            <Label htmlFor="improveTomorrow">
              One thing I'll do better tomorrow:
            </Label>
            <Textarea
              id="improveTomorrow"
              placeholder="How will you improve your response next time?"
              className="mt-1"
              rows={2}
              {...register("stoicMind.improvement")}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
