import { useFormContext } from "react-hook-form";
import { Swords } from "lucide-react";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import SectionHeader from "@/components/layout/section-header";
import { Card, CardContent } from "@/components/ui/card";
import type { DailyEntryForm } from "@shared/schema";

export default function StrategicStrikePlan() {
  const { register, watch } = useFormContext<DailyEntryForm>();
  
  const topPriority = watch("strategicPlan.topPriority");
  const distractions = watch("strategicPlan.distractions");
  const smartMove = watch("strategicPlan.smartMove");
  
  // Count completed fields
  const totalFields = 3;
  const completedFields = [
    !!topPriority,
    !!distractions,
    !!smartMove
  ].filter(Boolean).length;

  return (
    <Card>
      <CardContent className="p-5">
        <SectionHeader
          icon={Swords}
          title="Strategic Strike Plan"
          subtitle="Smart, Not Fast"
          completed={completedFields}
          total={totalFields}
        />
        
        <div className="space-y-4">
          <div className="group">
            <Label htmlFor="topPriority">
              What is my top priority?
            </Label>
            <Textarea
              id="topPriority"
              placeholder="Define your #1 priority for today"
              className="mt-1"
              rows={2}
              {...register("strategicPlan.topPriority")}
            />
          </div>

          <div className="group">
            <Label htmlFor="distractions">
              What distractions will I block?
            </Label>
            <Textarea
              id="distractions"
              placeholder="List potential distractions to avoid"
              className="mt-1"
              rows={2}
              {...register("strategicPlan.distractions")}
            />
          </div>

          <div className="group">
            <Label htmlFor="smartMove">
              One smart move to save time/energy:
            </Label>
            <Textarea
              id="smartMove"
              placeholder="What one thing could make everything easier?"
              className="mt-1"
              rows={2}
              {...register("strategicPlan.smartMove")}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
