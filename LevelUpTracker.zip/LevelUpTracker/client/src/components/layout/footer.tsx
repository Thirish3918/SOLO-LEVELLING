import { Link } from "wouter";
import { CalendarIcon, BarChart2, Settings } from "lucide-react";

export default function Footer() {
  return (
    <footer className="mt-10 bg-white dark:bg-gray-900 shadow-inner dark:shadow-blue-900/10">
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-600 dark:text-blue-300 text-sm mb-4 md:mb-0">
            Daily Level-Up Tracker — Your personal growth tool
          </p>
          <div className="flex space-x-6">
            <Link href="/history" className="text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-accent transition-colors flex items-center">
                <CalendarIcon className="h-4 w-4 mr-1" />
                <span className="text-sm">History</span>
            </Link>
            <Link href="/analytics" className="text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-accent transition-colors flex items-center">
                <BarChart2 className="h-4 w-4 mr-1" />
                <span className="text-sm">Analytics</span>
            </Link>
            <button className="text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-accent transition-colors flex items-center">
              <Settings className="h-4 w-4 mr-1" />
              <span className="text-sm">Settings</span>
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
