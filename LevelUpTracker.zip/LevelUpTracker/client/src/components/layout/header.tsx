import { useTheme } from "@/components/ui/theme-provider";
import { formatDate } from "@/utils/date-utils";
import { Moon, Sun, Flame, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import Notifications from "@/components/user/notifications";
import ProfileCard from "@/components/user/profile-card";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

export default function Header() {
  const { theme, setTheme } = useTheme();
  const currentDate = formatDate(new Date());
  
  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };
  
  return (
    <header className="relative py-4 bg-white dark:bg-gray-900 shadow-md dark:shadow-blue-900/20">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-3">
            {theme === "dark" ? (
              <Sparkles className="text-accent text-2xl" />
            ) : (
              <Flame className="text-primary text-2xl" />
            )}
            <h1 className="text-xl md:text-2xl font-semibold text-gray-800 dark:text-white bg-clip-text dark:bg-gradient-to-r dark:from-blue-400 dark:to-violet-400 dark:text-transparent">
              Daily Level-Up Tracker
            </h1>
          </div>
          <div className="flex items-center space-x-4">
            <Notifications />
            
            <Popover>
              <PopoverTrigger asChild>
                <Button 
                  variant="ghost"
                  size="icon"
                  className="rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 shadow-glow"
                >
                  <div className="h-6 w-6 rounded-full bg-primary/20 dark:bg-accent/20 flex items-center justify-center">
                    <span className="text-xs font-semibold text-primary dark:text-accent">
                      XP
                    </span>
                  </div>
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80 p-0" align="end">
                <ProfileCard />
              </PopoverContent>
            </Popover>
            
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleTheme}
              className="rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 shadow-glow"
            >
              {theme === "dark" ? (
                <Sun className="h-5 w-5 text-amber-300" />
              ) : (
                <Moon className="h-5 w-5 text-gray-600" />
              )}
              <span className="sr-only">Toggle theme</span>
            </Button>
            
            <div className="flex items-center">
              <span className="text-sm md:text-base text-gray-600 dark:text-blue-200">
                {currentDate}
              </span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
