import { ReactNode } from "react";
import { useTheme } from "@/components/ui/theme-provider";
import Header from "./header";
import Footer from "./footer";

interface PageContainerProps {
  children: ReactNode;
}

export default function PageContainer({ children }: PageContainerProps) {
  const { theme } = useTheme();
  
  return (
    <div className={`min-h-screen bg-neutral-light dark:bg-[#141824] transition-colors duration-300 ${
      theme === "dark" ? "dark-mode-jin-woo" : ""
    }`}>
      <Header />
      <div className="relative">
        {theme === "dark" && (
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTQwMCIgaGVpZ2h0PSI4MDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImEiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiIHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgcGF0dGVyblRyYW5zZm9ybT0ic2NhbGUoMykiPjxwYXRoIGQ9Ik0gMTAgMTAgbSAtOSAwIGEgOSA5IDAgMSAwIDE4IDAgYSA5IDkgMCAxIDAgLTE4IDAiIHN0cm9rZT0iIzIyNDRjYyIgc3Ryb2tlLXdpZHRoPSIwLjIiIGZpbGw9Im5vbmUiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjYSkiIG9wYWNpdHk9IjAuMSIvPjwvc3ZnPg==')] pointer-events-none opacity-30 z-0"
          />
        )}
        <div className="relative z-10">
          {children}
        </div>
      </div>
      <Footer />
    </div>
  );
}
