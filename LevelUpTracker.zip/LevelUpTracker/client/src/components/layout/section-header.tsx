import { ReactNode } from "react";
import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { ProgressBadge } from "@/components/ui/progress-badge";

interface SectionHeaderProps {
  icon: LucideIcon;
  title: string;
  subtitle?: string;
  completed: number;
  total: number;
  className?: string;
}

export default function SectionHeader({
  icon: Icon,
  title,
  subtitle,
  completed,
  total,
  className,
}: SectionHeaderProps) {
  return (
    <div className={cn("flex items-center mb-4", className)}>
      <div className="h-9 w-9 rounded-lg bg-primary/10 dark:bg-accent/20 flex items-center justify-center mr-3 shadow-sm dark:shadow-accent/30">
        <Icon className="h-5 w-5 text-primary dark:text-accent" />
      </div>
      <div>
        <h2 className="text-xl font-semibold text-gray-800 dark:text-white dark:bg-gradient-to-r dark:from-blue-300 dark:to-violet-300 dark:bg-clip-text dark:text-transparent">{title}</h2>
        {subtitle && (
          <p className="text-sm text-gray-600 dark:text-blue-300 italic">{subtitle}</p>
        )}
      </div>
      <div className="ml-auto">
        <ProgressBadge completed={completed} total={total} />
      </div>
    </div>
  );
}
