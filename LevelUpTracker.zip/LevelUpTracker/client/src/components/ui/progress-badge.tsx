import { cn } from "@/lib/utils";

interface ProgressBadgeProps {
  completed: number;
  total: number;
  className?: string;
}

export function ProgressBadge({ completed, total, className }: ProgressBadgeProps) {
  let statusClasses = "bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300";
  
  if (completed === total && total > 0) {
    statusClasses = "bg-green-100 dark:bg-green-800 text-green-800 dark:text-green-100";
  } else if (completed > 0) {
    statusClasses = "bg-blue-100 dark:bg-blue-800 text-blue-800 dark:text-blue-100";
  }
  
  return (
    <span className={cn("text-xs font-medium px-2 py-1 rounded-full", statusClasses, className)}>
      {completed}/{total} complete
    </span>
  );
}
