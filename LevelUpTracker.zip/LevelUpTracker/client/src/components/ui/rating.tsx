import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";

interface RatingProps {
  value: number | undefined;
  onChange: (value: number) => void;
  max?: number;
  className?: string;
}

export function Rating({ value, onChange, max = 10, className }: RatingProps) {
  const [selectedRating, setSelectedRating] = useState<number | undefined>(value);
  
  // Update the selected rating when the value prop changes
  useEffect(() => {
    setSelectedRating(value);
  }, [value]);
  
  const handleRatingClick = (rating: number) => {
    setSelectedRating(rating);
    onChange(rating);
  };
  
  return (
    <div className={cn("flex items-center space-x-1", className)}>
      {[...Array(max)].map((_, index) => {
        const rating = index + 1;
        const isSelected = selectedRating === rating;
        
        return (
          <button
            key={rating}
            type="button"
            onClick={() => handleRatingClick(rating)}
            className={cn(
              "h-8 w-8 rounded-full flex items-center justify-center focus:outline-none transition-colors",
              isSelected
                ? "bg-primary text-white"
                : "bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600"
            )}
          >
            {rating}
          </button>
        );
      })}
    </div>
  );
}
