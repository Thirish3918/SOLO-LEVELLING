import { useState } from "react";
import { Medal, Flame, Star, Sparkles, Trophy, Award } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

// Example badges to showcase
const exampleBadges = [
  {
    id: 1,
    name: "Deep Work Beast",
    description: "Complete 7 days with at least 2 hours of deep work each day",
    requirement: "deepWorkStreak7",
    icon: <Flame className="h-6 w-6 text-orange-500" />
  },
  {
    id: 2,
    name: "Shadow Monarch",
    description: "Connect with at least 10 different professionals",
    requirement: "shadowArmy10",
    icon: <Star className="h-6 w-6 text-purple-500" />
  },
  {
    id: 3,
    name: "Task Assassin",
    description: "Complete all daily tasks for 5 consecutive days",
    requirement: "taskStreak5",
    icon: <Sparkles className="h-6 w-6 text-blue-500" />
  },
  {
    id: 4,
    name: "Leveling Beast",
    description: "Reach level 10",
    requirement: "level10",
    icon: <Trophy className="h-6 w-6 text-yellow-500" />
  },
  {
    id: 5,
    name: "Growth Master",
    description: "Rate your growth as 10/10 for 3 consecutive days",
    requirement: "perfectGrowth3",
    icon: <Award className="h-6 w-6 text-green-500" />
  }
];

export default function BadgesShowcase() {
  const [selectedBadge, setSelectedBadge] = useState(exampleBadges[0]);
  
  return (
    <Card className="shadow-glow overflow-hidden">
      <CardHeader className="bg-gradient-to-r from-blue-900 to-indigo-900 text-white">
        <CardTitle className="text-gradient">Available Badges</CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-2 mb-4">
          {exampleBadges.map(badge => (
            <div
              key={badge.id}
              className={`flex flex-col items-center p-2 rounded-lg cursor-pointer transition-all duration-200
                ${selectedBadge.id === badge.id 
                  ? 'bg-primary/10 dark:bg-primary/20 shadow-glow' 
                  : 'bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700'}`}
              onClick={() => setSelectedBadge(badge)}
            >
              <div className="w-12 h-12 flex items-center justify-center rounded-full bg-primary/5 dark:bg-primary/10 mb-2 shadow-glow">
                {badge.icon}
              </div>
              <span className="text-xs text-center font-medium">{badge.name}</span>
            </div>
          ))}
        </div>
        
        <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
          <div className="flex items-center mb-2">
            <div className="mr-3">
              {selectedBadge.icon}
            </div>
            <div>
              <h4 className="font-bold text-lg text-gradient">{selectedBadge.name}</h4>
              <p className="text-gray-600 dark:text-gray-300 text-sm">{selectedBadge.description}</p>
            </div>
          </div>
          <p className="text-xs mt-2 text-gray-500 dark:text-gray-400">
            Complete consistent daily check-ins to earn these badges and gain XP bonuses!
          </p>
        </div>
      </CardContent>
    </Card>
  );
}