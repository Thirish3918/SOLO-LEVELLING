import { useState } from 'react';
import { Star, Bell, Award, Zap, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface NotificationProps {
  id: number;
  title: string;
  message: string;
  time: string;
  type: 'xp' | 'badge' | 'streak' | 'reminder';
  read: boolean;
}

// Example notification data
const initialNotifications: NotificationProps[] = [
  {
    id: 1,
    title: 'New badge unlocked!',
    message: 'You earned the "Deep Work Beast" badge for completing 7 days of deep work',
    time: '2h ago',
    type: 'badge',
    read: false
  },
  {
    id: 2,
    title: 'XP Milestone',
    message: 'You reached 750 XP and advanced to Level 5!',
    time: '1d ago',
    type: 'xp',
    read: false
  },
  {
    id: 3, 
    title: '3 Day Streak',
    message: 'You\'ve been consistent for 3 days. Keep going!',
    time: '1d ago',
    type: 'streak',
    read: true
  }
];

export default function Notifications() {
  const [notifications, setNotifications] = useState(initialNotifications);
  const [isOpen, setIsOpen] = useState(false);
  
  const unreadCount = notifications.filter(n => !n.read).length;
  
  const markAsRead = (id: number) => {
    setNotifications(notifications.map(n => 
      n.id === id ? { ...n, read: true } : n
    ));
  };
  
  const deleteNotification = (id: number) => {
    setNotifications(notifications.filter(n => n.id !== id));
  };
  
  const markAllAsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })));
  };
  
  const getIcon = (type: string) => {
    switch(type) {
      case 'badge': return <Award className="h-5 w-5 text-yellow-500" />;
      case 'xp': return <Zap className="h-5 w-5 text-blue-500" />;
      case 'streak': return <Star className="h-5 w-5 text-purple-500" />;
      default: return <Bell className="h-5 w-5 text-gray-500" />;
    }
  };
  
  return (
    <div className="relative">
      <Button 
        variant="outline" 
        size="sm" 
        className="flex items-center gap-2 relative rounded-full"
        onClick={() => setIsOpen(!isOpen)}
      >
        <Bell className="h-4 w-4" />
        <span className="text-sm">Notifications</span>
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] text-white">
            {unreadCount}
          </span>
        )}
      </Button>
      
      {isOpen && (
        <div className="absolute right-0 mt-2 z-50 w-80 md:w-96 bg-white dark:bg-gray-800 shadow-lg rounded-md overflow-hidden">
          <div className="p-3 border-b dark:border-gray-700 flex items-center justify-between">
            <h3 className="font-medium">Notifications</h3>
            {unreadCount > 0 && (
              <Button variant="ghost" size="sm" onClick={markAllAsRead} className="text-xs h-7">
                Mark all as read
              </Button>
            )}
          </div>
          
          <div className="max-h-[300px] overflow-y-auto">
            {notifications.length === 0 ? (
              <div className="p-4 text-center text-sm text-gray-500">
                No notifications
              </div>
            ) : (
              <ul>
                {notifications.map((notification) => (
                  <li 
                    key={notification.id} 
                    className={cn(
                      "p-3 border-b dark:border-gray-700 last:border-0 flex items-start gap-3 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors",
                      !notification.read && "bg-blue-50 dark:bg-blue-900/20"
                    )}
                    onClick={() => markAsRead(notification.id)}
                  >
                    <div className="mt-1">
                      {getIcon(notification.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <p className="font-medium text-sm truncate">{notification.title}</p>
                        <span className="text-xs text-gray-500 whitespace-nowrap">{notification.time}</span>
                      </div>
                      <p className="text-xs text-gray-600 dark:text-gray-300 mt-1">{notification.message}</p>
                    </div>
                    <button 
                      className="mt-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteNotification(notification.id);
                      }}
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      )}
    </div>
  );
}