import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Trophy, Star, Award, Zap, Shield } from "lucide-react";
import { User } from "@shared/schema";

export default function ProfileCard() {
  // Fetch user data
  const { data: user, isLoading } = useQuery<User>({
    queryKey: ['/api/user']
  });

  if (isLoading) {
    return (
      <Card className="w-full overflow-hidden animate-pulse">
        <CardHeader className="bg-gray-200 dark:bg-gray-800 h-24"></CardHeader>
        <CardContent className="p-6">
          <div className="h-16 bg-gray-100 dark:bg-gray-700 rounded-md"></div>
        </CardContent>
      </Card>
    );
  }

  // Default values if user not yet loaded
  const displayUser = user || {
    id: 1,
    username: "Monarch",
    password: "",
    xp: 750,
    level: 5,
    streakDays: 3,
    lastCheckIn: new Date()
  };
  
  // For display purposes
  const currentStreak = displayUser.streakDays;
  const bestStreak = 7; // Normally would come from the user object

  // Calculate level and XP progress
  const levelXp = displayUser.level * 1000;
  const nextLevelXp = (displayUser.level + 1) * 1000;
  const currentLevelProgress = displayUser.xp - levelXp;
  const xpToNextLevel = nextLevelXp - levelXp;
  const progressPercentage = Math.floor((currentLevelProgress / xpToNextLevel) * 100);

  return (
    <Card className="shadow-glow overflow-hidden">
      <CardHeader className="bg-gradient-to-r from-gray-900 to-indigo-900 text-white p-6 pb-10 relative">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xs uppercase tracking-wider opacity-80">Shadow Monarch</span>
            <CardTitle className="text-gradient text-2xl md:text-3xl font-bold mt-1">
              {displayUser.username}
            </CardTitle>
          </div>
          <div className="flex items-center space-x-3">
            <div className="flex flex-col items-center">
              <Star className="w-5 h-5 text-yellow-400" />
              <span className="text-xs mt-1">{displayUser.level}</span>
            </div>
            <div className="flex flex-col items-center">
              <Zap className="w-5 h-5 text-blue-400" />
              <span className="text-xs mt-1">{displayUser.xp} XP</span>
            </div>
            <div className="flex flex-col items-center">
              <Shield className="w-5 h-5 text-green-400" />
              <span className="text-xs mt-1">{currentStreak} days</span>
            </div>
          </div>
        </div>
      </CardHeader>
      
      <div className="-mt-4 mx-4 z-10 relative">
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center">
              <Trophy className="mr-2 h-5 w-5 text-amber-500" />
              <span className="font-medium">Level {displayUser.level}</span>
            </div>
            <span className="text-xs text-gray-500 dark:text-gray-400">
              {currentLevelProgress} / {xpToNextLevel} XP to Level {displayUser.level + 1}
            </span>
          </div>
          
          <Progress value={progressPercentage} className="h-2" />
          
          <div className="mt-4 grid grid-cols-2 gap-2">
            <div className="text-center p-2 bg-gray-100 dark:bg-gray-700 rounded-md">
              <p className="text-xs text-gray-500 dark:text-gray-400">Current Streak</p>
              <p className="text-lg font-bold text-blue-600 dark:text-blue-400">{currentStreak} days</p>
            </div>
            <div className="text-center p-2 bg-gray-100 dark:bg-gray-700 rounded-md">
              <p className="text-xs text-gray-500 dark:text-gray-400">Best Streak</p>
              <p className="text-lg font-bold text-indigo-600 dark:text-indigo-400">{bestStreak} days</p>
            </div>
          </div>
        </div>
      </div>
      
      <CardContent className="p-6 pt-4">
        <div className="flex justify-between items-center text-sm text-gray-600 dark:text-gray-300">
          <div className="flex items-center">
            <Award className="mr-2 h-4 w-4 text-primary" />
            <span>Rising as a shadow monarch</span>
          </div>
          <span>Since {displayUser.lastCheckIn ? new Date(displayUser.lastCheckIn).toLocaleDateString() : 'today'}</span>
        </div>
      </CardContent>
    </Card>
  );
}