import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { ChevronLeft, BarChart2, TrendingUp, Calendar } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import type { DailyEntry } from "@shared/schema";

export default function Analytics() {
  const { data: entries, isLoading } = useQuery<DailyEntry[]>({
    queryKey: ['/api/daily-entries', { limit: 30 }],
  });
  
  // Prepare data for charts
  const growthRatingData = entries?.filter(entry => entry.growthRating !== undefined && entry.growthRating !== null)
    .map(entry => ({
      date: new Date(entry.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      rating: entry.growthRating
    }))
    .reverse();
  
  const deepWorkData = entries?.filter(entry => entry.deepWorkHours !== undefined && entry.deepWorkHours !== null)
    .map(entry => ({
      date: new Date(entry.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      hours: entry.deepWorkHours
    }))
    .reverse();
  
  // Calculate averages
  const avgGrowthRating = growthRatingData && growthRatingData.length > 0
    ? (growthRatingData.reduce((sum, item) => sum + (item.rating || 0), 0) / growthRatingData.length).toFixed(1)
    : 'N/A';
  
  const avgDeepWorkHours = deepWorkData && deepWorkData.length > 0
    ? (deepWorkData.reduce((sum, item) => sum + (item.hours || 0), 0) / deepWorkData.length).toFixed(1)
    : 'N/A';
  
  // Calculate streaks (consecutive days with entries)
  const calculateStreak = (entries?: DailyEntry[]): number => {
    if (!entries || entries.length === 0) return 0;
    
    let streak = 1; // Start with 1 for today
    const sortedEntries = [...entries].sort((a, b) => 
      new Date(b.date).getTime() - new Date(a.date).getTime()
    );
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayTime = today.getTime();
    
    // Check if the latest entry is from today
    const latestEntryDate = new Date(sortedEntries[0].date);
    latestEntryDate.setHours(0, 0, 0, 0);
    
    // If the latest entry is not from today, start streak calculation from the latest entry
    if (latestEntryDate.getTime() !== todayTime) {
      let currentDate = latestEntryDate;
      
      for (let i = 1; i < sortedEntries.length; i++) {
        const nextEntryDate = new Date(sortedEntries[i].date);
        nextEntryDate.setHours(0, 0, 0, 0);
        
        // Calculate the difference in days
        const diffTime = currentDate.getTime() - nextEntryDate.getTime();
        const diffDays = diffTime / (1000 * 60 * 60 * 24);
        
        // If the difference is exactly 1 day, increase the streak
        if (diffDays === 1) {
          streak++;
          currentDate = nextEntryDate;
        } else {
          break;
        }
      }
    } else {
      // Start from today and check previous days
      let currentDate = today;
      
      for (const entry of sortedEntries) {
        const entryDate = new Date(entry.date);
        entryDate.setHours(0, 0, 0, 0);
        
        // Calculate the difference in days
        const diffTime = currentDate.getTime() - entryDate.getTime();
        const diffDays = diffTime / (1000 * 60 * 60 * 24);
        
        // If the difference is exactly 1 day, increase the streak
        if (diffDays === 1) {
          streak++;
          currentDate = entryDate;
        } else if (diffDays !== 0) { // If not the same day
          break;
        }
      }
    }
    
    return streak;
  };
  
  const streak = calculateStreak(entries);
  
  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold flex items-center">
          <BarChart2 className="h-6 w-6 mr-2" />
          Growth Analytics
        </h1>
        <Link href="/">
          <Button variant="outline" className="flex items-center">
            <ChevronLeft className="h-4 w-4 mr-1" /> Back to Today
          </Button>
        </Link>
      </div>
      
      {isLoading ? (
        <div className="text-center py-10">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]" role="status">
            <span className="!absolute !-m-px !h-px !w-px !overflow-hidden !whitespace-nowrap !border-0 !p-0 ![clip:rect(0,0,0,0)]">
              Loading...
            </span>
          </div>
          <p className="mt-4 text-gray-600 dark:text-gray-300">Loading your analytics data...</p>
        </div>
      ) : (
        <>
          {/* Stats Summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500 dark:text-gray-400 flex items-center">
                  <Calendar className="h-4 w-4 mr-1" />
                  Current Streak
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{streak} days</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500 dark:text-gray-400 flex items-center">
                  <TrendingUp className="h-4 w-4 mr-1" />
                  Average Growth Rating
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{avgGrowthRating}</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500 dark:text-gray-400 flex items-center">
                  <BarChart2 className="h-4 w-4 mr-1" />
                  Avg. Deep Work Hours
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{avgDeepWorkHours}</div>
              </CardContent>
            </Card>
          </div>
          
          {/* Charts */}
          <div className="grid grid-cols-1 gap-6">
            {growthRatingData && growthRatingData.length > 0 ? (
              <Card>
                <CardHeader>
                  <CardTitle>Growth Rating Trend</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={growthRatingData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" />
                        <YAxis domain={[0, 10]} />
                        <Tooltip />
                        <Bar dataKey="rating" fill="hsl(var(--primary))" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>Growth Rating Trend</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-10 text-gray-500">
                    No growth rating data available yet. Start tracking your growth to see analytics.
                  </div>
                </CardContent>
              </Card>
            )}
            
            {deepWorkData && deepWorkData.length > 0 ? (
              <Card>
                <CardHeader>
                  <CardTitle>Deep Work Hours</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={deepWorkData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="hours" fill="hsl(var(--chart-1))" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>Deep Work Hours</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-10 text-gray-500">
                    No deep work data available yet. Log your deep work hours to track your productivity.
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </>
      )}
    </div>
  );
}
