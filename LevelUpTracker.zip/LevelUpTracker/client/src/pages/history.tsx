import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Calendar, ChevronLeft } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatDateShort } from "@/utils/date-utils";
import type { DailyEntry } from "@shared/schema";

export default function History() {
  const [limit, setLimit] = useState(10);
  
  const { data: entries, isLoading } = useQuery<DailyEntry[]>({
    queryKey: ['/api/daily-entries', { limit }],
  });
  
  const loadMore = () => {
    setLimit(prev => prev + 10);
  };
  
  // Helper function to calculate completion percentage
  const calculateCompletion = (entry: DailyEntry): number => {
    let completed = 0;
    let total = 0;
    
    // Daily Stats
    if (entry.skillStudied) completed++;
    if (entry.mediaConsumed) completed++;
    if (entry.physicalTraining) completed++;
    if (entry.deepWorkHours) completed++;
    if (entry.growthRating) completed++;
    total += 5;
    
    // Count the rest of the sections
    // Helper function to count completed fields in a JSON object
    const countCompletedFields = (obj?: Record<string, any>): [number, number] => {
      if (!obj) return [0, 0];
      
      let comp = 0;
      let tot = 0;
      
      Object.entries(obj).forEach(([key, value]) => {
        // Skip non-string/number values (like objects/arrays) for this level
        if (typeof value === 'string') {
          tot++;
          if (value.trim() !== '') comp++;
        } else if (typeof value === 'number' || typeof value === 'boolean') {
          tot++;
          if (value) comp++;
        }
      });
      
      return [comp, tot];
    };
    
    // Add silent execution tasks
    if (entry.silentExecution) {
      if (entry.silentExecution.task1?.description && entry.silentExecution.task1?.completed) completed++;
      if (entry.silentExecution.task2?.description && entry.silentExecution.task2?.completed) completed++;
      if (entry.silentExecution.task3?.description && entry.silentExecution.task3?.completed) completed++;
      total += 3;
    }
    
    // Add other sections
    const sections = [
      entry.strategicPlan,
      entry.purpose,
      entry.dungeonDive,
      entry.shadowArmy,
      entry.stoicMind,
      entry.reflection
    ];
    
    sections.forEach(section => {
      if (section) {
        const [sectionCompleted, sectionTotal] = countCompletedFields(section);
        completed += sectionCompleted;
        total += sectionTotal;
      }
    });
    
    return total > 0 ? Math.round((completed / total) * 100) : 0;
  };
  
  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold flex items-center">
          <Calendar className="h-6 w-6 mr-2" />
          Your Daily Entry History
        </h1>
        <Link href="/">
          <Button variant="outline" className="flex items-center">
            <ChevronLeft className="h-4 w-4 mr-1" /> Back to Today
          </Button>
        </Link>
      </div>
      
      {isLoading ? (
        <div className="text-center py-10">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]" role="status">
            <span className="!absolute !-m-px !h-px !w-px !overflow-hidden !whitespace-nowrap !border-0 !p-0 ![clip:rect(0,0,0,0)]">
              Loading...
            </span>
          </div>
          <p className="mt-4 text-gray-600 dark:text-gray-300">Loading your history...</p>
        </div>
      ) : (
        <>
          {entries && entries.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {entries.map((entry) => {
                const completionPercent = calculateCompletion(entry);
                const date = new Date(entry.date);
                
                return (
                  <Link key={entry.id} href={`/history/${entry.id}`}>
                    <Card className="cursor-pointer hover:shadow-md transition-shadow">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg">{formatDateShort(date)}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                            <div 
                              className="bg-primary h-2 rounded-full"
                              style={{ width: `${completionPercent}%` }}
                            ></div>
                          </div>
                          <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
                            <span>{completionPercent}% Complete</span>
                          </div>
                          
                          {entry.growthRating && (
                            <div className="mt-3 flex items-center">
                              <span className="text-sm text-gray-600 dark:text-gray-300">Growth Rating:</span>
                              <span className="ml-2 h-6 w-6 rounded-full bg-primary text-white text-xs flex items-center justify-center">
                                {entry.growthRating}
                              </span>
                            </div>
                          )}
                          
                          {entry.skillStudied && (
                            <div className="mt-1 text-sm text-gray-600 dark:text-gray-300">
                              <span className="font-medium">Skill:</span> {entry.skillStudied}
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-10">
              <p className="text-gray-600 dark:text-gray-300">
                No entries found. Start tracking your growth today!
              </p>
            </div>
          )}
          
          {entries && entries.length >= limit && (
            <div className="mt-6 text-center">
              <Button onClick={loadMore} variant="outline">
                Load More
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
