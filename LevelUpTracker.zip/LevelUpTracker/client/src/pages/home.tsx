import { useEffect, useMemo, useState } from "react";
import { useForm, FormProvider } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Save } from "lucide-react";

// Form Components
import DailyStats from "@/components/daily-tracker/daily-stats";
import SilentExecution from "@/components/daily-tracker/silent-execution";
import StrategicStrikePlan from "@/components/daily-tracker/strategic-strike-plan";
import PurposeLockIn from "@/components/daily-tracker/purpose-lock-in";
import DungeonDive from "@/components/daily-tracker/dungeon-dive";
import ShadowArmy from "@/components/daily-tracker/shadow-army";
import StoicMind from "@/components/daily-tracker/stoic-mind";
import DayReflection from "@/components/daily-tracker/day-reflection";
import ProgressBar from "@/components/daily-tracker/progress-bar";
import ProfileCard from "@/components/user/profile-card";
import Notifications from "@/components/user/notifications";
import BadgesShowcase from "@/components/user/badges-showcase";

import type { DailyEntryForm, DailyEntry } from "@shared/schema";
import { dailyEntryFormSchema } from "@shared/schema";

// Default empty form values
const defaultFormValues: DailyEntryForm = {
  skillStudied: "",
  mediaConsumed: "",
  physicalTraining: "",
  deepWorkHours: undefined,
  growthRating: undefined,
  silentExecution: {
    task1: { description: "", completed: false },
    task2: { description: "", completed: false },
    task3: { description: "", completed: false },
  },
  strategicPlan: {
    topPriority: "",
    distractions: "",
    smartMove: "",
  },
  purpose: {
    whoFor: "",
    myPurpose: "",
    todayReminder: "",
  },
  dungeonDive: {
    startTime: "",
    endTime: "",
    outcome: "",
  },
  shadowArmy: {
    nameRole: "",
    purpose: "",
    leadOrLearn: "",
  },
  stoicMind: {
    challenges: "",
    response: "",
    improvement: "",
  },
  reflection: {
    wins: "",
    growthAreas: "",
    lessonLearned: "",
  },
};

export default function Home() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(true);
  
  // Setup form
  const methods = useForm<DailyEntryForm>({
    resolver: zodResolver(dailyEntryFormSchema),
    defaultValues: defaultFormValues,
    mode: "onChange",
  });
  
  const { handleSubmit, reset, watch, formState } = methods;
  const formValues = watch();
  
  // Fetch today's entry
  const { data: dailyEntry, isLoading: isFetchingEntry } = useQuery<DailyEntry>({
    queryKey: ['/api/daily-entry']
  });

  // Handle daily entry data changes
  useEffect(() => {
    if (dailyEntry) {
      // Only reset if we have data to avoid clearing user input
      reset({
        skillStudied: dailyEntry.skillStudied || "",
        mediaConsumed: dailyEntry.mediaConsumed || "",
        physicalTraining: dailyEntry.physicalTraining || "",
        deepWorkHours: dailyEntry.deepWorkHours || undefined,
        growthRating: dailyEntry.growthRating || undefined,
        silentExecution: dailyEntry.silentExecution || {
          task1: { description: "", completed: false },
          task2: { description: "", completed: false },
          task3: { description: "", completed: false },
        },
        strategicPlan: dailyEntry.strategicPlan || {
          topPriority: "",
          distractions: "",
          smartMove: "",
        },
        purpose: dailyEntry.purpose || {
          whoFor: "",
          myPurpose: "",
          todayReminder: "",
        },
        dungeonDive: dailyEntry.dungeonDive || {
          startTime: "",
          endTime: "",
          outcome: "",
        },
        shadowArmy: dailyEntry.shadowArmy || {
          nameRole: "",
          purpose: "",
          leadOrLearn: "",
        },
        stoicMind: dailyEntry.stoicMind || {
          challenges: "",
          response: "",
          improvement: "",
        },
        reflection: dailyEntry.reflection || {
          wins: "",
          growthAreas: "",
          lessonLearned: "",
        },
      });
      setIsLoading(false);
    }
  }, [dailyEntry, reset]);
  
  // Save mutation
  const { mutate: saveDailyEntry, isPending: isSaving } = useMutation({
    mutationFn: async (data: DailyEntryForm) => {
      return apiRequest('POST', '/api/daily-entry', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/daily-entry'] });
      toast({
        title: "Success",
        description: "Your daily progress has been saved.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save your daily entry.",
        variant: "destructive",
      });
    }
  });
  
  const onSubmit = (data: DailyEntryForm) => {
    saveDailyEntry(data);
  };
  
  // Calculate progress for each section
  const sections = useMemo(() => {
    const calculateSectionProgress = (
      fields: Record<string, any>,
      fieldKeys: string[]
    ) => {
      const total = fieldKeys.length;
      const completed = fieldKeys.filter(key => {
        const value = fields[key];
        // Check for non-empty values
        if (typeof value === 'string') return value.trim() !== '';
        if (typeof value === 'number') return true;
        if (typeof value === 'boolean') return value;
        return value !== null && value !== undefined;
      }).length;
      return { completed, total };
    };
    
    return [
      {
        title: "Daily Stats",
        ...calculateSectionProgress(formValues, [
          'skillStudied', 'mediaConsumed', 'physicalTraining', 'deepWorkHours', 'growthRating'
        ]),
        completedFields: [
          !!formValues.skillStudied,
          !!formValues.mediaConsumed,
          !!formValues.physicalTraining,
          !!formValues.deepWorkHours,
          !!formValues.growthRating
        ].filter(Boolean).length,
        totalFields: 5
      },
      {
        title: "Silent Execution",
        completedFields: [
          formValues.silentExecution.task1.description && formValues.silentExecution.task1.completed,
          formValues.silentExecution.task2.description && formValues.silentExecution.task2.completed,
          formValues.silentExecution.task3.description && formValues.silentExecution.task3.completed
        ].filter(Boolean).length,
        totalFields: 3
      },
      {
        title: "Strategic Strike Plan",
        completedFields: [
          !!formValues.strategicPlan.topPriority,
          !!formValues.strategicPlan.distractions,
          !!formValues.strategicPlan.smartMove
        ].filter(Boolean).length,
        totalFields: 3
      },
      {
        title: "Purpose Lock-in",
        completedFields: [
          !!formValues.purpose.whoFor,
          !!formValues.purpose.myPurpose,
          !!formValues.purpose.todayReminder
        ].filter(Boolean).length,
        totalFields: 3
      },
      {
        title: "Dungeon Dive",
        completedFields: [
          !!formValues.dungeonDive.startTime,
          !!formValues.dungeonDive.endTime,
          !!formValues.dungeonDive.outcome
        ].filter(Boolean).length,
        totalFields: 3
      },
      {
        title: "Shadow Army",
        completedFields: [
          !!formValues.shadowArmy.nameRole,
          !!formValues.shadowArmy.purpose,
          !!formValues.shadowArmy.leadOrLearn
        ].filter(Boolean).length,
        totalFields: 3
      },
      {
        title: "Stoic Mind Training",
        completedFields: [
          !!formValues.stoicMind.challenges,
          !!formValues.stoicMind.response,
          !!formValues.stoicMind.improvement
        ].filter(Boolean).length,
        totalFields: 3
      },
      {
        title: "End of Day Reflection",
        completedFields: [
          !!formValues.reflection.wins,
          !!formValues.reflection.growthAreas,
          !!formValues.reflection.lessonLearned
        ].filter(Boolean).length,
        totalFields: 3
      }
    ];
  }, [formValues]);

  if (isLoading || isFetchingEntry) {
    return (
      <div className="container mx-auto px-4 py-10 flex items-center justify-center min-h-[50vh]">
        <div className="text-center">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]" role="status">
            <span className="!absolute !-m-px !h-px !w-px !overflow-hidden !whitespace-nowrap !border-0 !p-0 ![clip:rect(0,0,0,0)]">
              Loading...
            </span>
          </div>
          <p className="mt-4 text-gray-600 dark:text-gray-300">Loading your daily tracker...</p>
        </div>
      </div>
    );
  }

  return (
    <FormProvider {...methods}>
      <form onSubmit={handleSubmit(onSubmit)}>
        <ProgressBar sections={sections} />
        
        <main className="container mx-auto px-4 py-6">
          {/* Display Profile Card */}
          <div className="mb-6">
            <ProfileCard />
            <div className="mt-4 flex justify-center">
              <div className="bg-white dark:bg-gray-800 shadow-md p-2 rounded-lg">
                <Notifications />
              </div>
            </div>
            <div className="mt-6">
              <BadgesShowcase />
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <DailyStats />
            <SilentExecution />
            <StrategicStrikePlan />
            <PurposeLockIn />
            <DungeonDive />
            <ShadowArmy />
            <StoicMind />
            <DayReflection />
          </div>
          
          {/* Save Progress */}
          <div className="mt-6 flex justify-center">
            <Button 
              type="submit"
              disabled={isSaving}
              className="px-6 py-3 flex items-center"
              size="lg"
            >
              {isSaving ? (
                <div className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-solid border-current border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite] mr-2"></div>
              ) : (
                <Save className="mr-2 h-4 w-4" />
              )}
              {isSaving ? "Saving..." : "Save Progress"}
            </Button>
          </div>
        </main>
      </form>
    </FormProvider>
  );
}
