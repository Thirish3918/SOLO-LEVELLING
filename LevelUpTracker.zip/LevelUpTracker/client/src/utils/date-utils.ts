import { format, parseISO } from "date-fns";

export function formatDate(date: Date | string): string {
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return format(dateObj, 'EEEE, MMMM d, yyyy');
}

export function formatDateShort(date: Date | string): string {
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return format(dateObj, 'MMM d, yyyy');
}

export function formatTime(time: string): string {
  if (!time) return '';
  
  try {
    // Convert 24-hour time format to 12-hour with AM/PM
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours, 10);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const hour12 = hour % 12 || 12; // Convert 0 to 12
    
    return `${hour12}:${minutes} ${ampm}`;
  } catch (e) {
    return time;
  }
}

export function getDateString(date: Date): string {
  return format(date, 'yyyy-MM-dd');
}

export function parseISODate(dateString: string): Date {
  return parseISO(dateString);
}
