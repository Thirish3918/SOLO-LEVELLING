import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { dailyEntryFormSchema, type DailyEntryForm } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

// Helper function to calculate XP based on entry completion
function calculateCompletionXP(entryData: DailyEntryForm): number {
  let completedFields = 0;
  let totalFields = 0;
  
  // Count completed fields in daily stats
  if (entryData.skillStudied) completedFields++;
  if (entryData.mediaConsumed) completedFields++;
  if (entryData.physicalTraining) completedFields++;
  if (entryData.deepWorkHours) completedFields++;
  if (entryData.growthRating) completedFields++;
  totalFields += 5;
  
  // Count completed fields in silent execution
  if (entryData.silentExecution.task1.description && entryData.silentExecution.task1.completed) completedFields++;
  if (entryData.silentExecution.task2.description && entryData.silentExecution.task2.completed) completedFields++;
  if (entryData.silentExecution.task3.description && entryData.silentExecution.task3.completed) completedFields++;
  totalFields += 3;
  
  // Count completed fields in strategic plan
  if (entryData.strategicPlan.topPriority) completedFields++;
  if (entryData.strategicPlan.distractions) completedFields++;
  if (entryData.strategicPlan.smartMove) completedFields++;
  totalFields += 3;
  
  // Count completed fields in purpose
  if (entryData.purpose.whoFor) completedFields++;
  if (entryData.purpose.myPurpose) completedFields++;
  if (entryData.purpose.todayReminder) completedFields++;
  totalFields += 3;
  
  // Count completed fields in dungeon dive
  if (entryData.dungeonDive.startTime) completedFields++;
  if (entryData.dungeonDive.endTime) completedFields++;
  if (entryData.dungeonDive.outcome) completedFields++;
  totalFields += 3;
  
  // Count completed fields in shadow army
  if (entryData.shadowArmy.nameRole) completedFields++;
  if (entryData.shadowArmy.purpose) completedFields++;
  if (entryData.shadowArmy.leadOrLearn) completedFields++;
  totalFields += 3;
  
  // Count completed fields in stoic mind
  if (entryData.stoicMind.challenges) completedFields++;
  if (entryData.stoicMind.response) completedFields++;
  if (entryData.stoicMind.improvement) completedFields++;
  totalFields += 3;
  
  // Count completed fields in reflection
  if (entryData.reflection.wins) completedFields++;
  if (entryData.reflection.growthAreas) completedFields++;
  if (entryData.reflection.lessonLearned) completedFields++;
  totalFields += 3;
  
  // Calculate XP: 1 XP per completed field, bonus for high completion
  const completionPercentage = (completedFields / totalFields) * 100;
  let xp = completedFields;
  
  // Bonus XP for completion milestones
  if (completionPercentage >= 50) xp += 5;  // 50% completion bonus
  if (completionPercentage >= 75) xp += 10; // 75% completion bonus
  if (completionPercentage >= 100) xp += 20; // 100% completion bonus
  
  return xp;
}

// Helper function to check and award badges
async function checkAndAwardBadges(userId: number, entryData: DailyEntryForm): Promise<void> {
  const user = await storage.getUser(userId);
  if (!user) return;
  
  // Get last 7 days of entries
  const entries = await storage.getAllDailyEntriesByUser(userId, 7);
  
  // Check for Deep Work Beast badge
  if (entries.length >= 7 && 
      entries.every(entry => entry.deepWorkHours && entry.deepWorkHours >= 2)) {
    const badge = Array.from((await storage.getAllBadges()))
      .find(b => b.requirement === 'deepWorkStreak7');
    
    if (badge && !(await storage.hasBadge(userId, badge.id))) {
      await storage.awardBadgeToUser(userId, badge.id);
    }
  }
  
  // Check for Task Assassin badge
  if (entries.length >= 5 && 
      entries.every(entry => 
        entry.silentExecution?.task1.completed && 
        entry.silentExecution?.task2.completed && 
        entry.silentExecution?.task3.completed)) {
    const badge = Array.from((await storage.getAllBadges()))
      .find(b => b.requirement === 'taskStreak5');
    
    if (badge && !(await storage.hasBadge(userId, badge.id))) {
      await storage.awardBadgeToUser(userId, badge.id);
    }
  }
  
  // Check for Growth Master badge
  if (entries.length >= 3 && 
      entries.slice(0, 3).every(entry => entry.growthRating === 10)) {
    const badge = Array.from((await storage.getAllBadges()))
      .find(b => b.requirement === 'perfectGrowth3');
    
    if (badge && !(await storage.hasBadge(userId, badge.id))) {
      await storage.awardBadgeToUser(userId, badge.id);
    }
  }
  
  // Check for Shadow Monarch badge - based on number of unique connections
  const shadowEntries = await storage.getAllDailyEntriesByUser(userId, 100);
  const uniqueConnections = new Set<string>();
  
  for (const entry of shadowEntries) {
    if (entry.shadowArmy && entry.shadowArmy.nameRole) {
      uniqueConnections.add(entry.shadowArmy.nameRole.toLowerCase().trim());
    }
  }
  
  if (uniqueConnections.size >= 10) {
    const badge = Array.from((await storage.getAllBadges()))
      .find(b => b.requirement === 'shadowArmy10');
    
    if (badge && !(await storage.hasBadge(userId, badge.id))) {
      await storage.awardBadgeToUser(userId, badge.id);
    }
  }
  
  // Check for Leveling Beast badge
  if (user.level >= 10) {
    const badge = Array.from((await storage.getAllBadges()))
      .find(b => b.requirement === 'level10');
    
    if (badge && !(await storage.hasBadge(userId, badge.id))) {
      await storage.awardBadgeToUser(userId, badge.id);
    }
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Get today's entry or create a new one
  app.get("/api/daily-entry", async (req: Request, res: Response) => {
    try {
      // For simplicity, use a fixed user ID since we're not implementing auth
      const userId = 1;
      const today = new Date();
      
      // Try to find an entry for today
      const existingEntry = await storage.getDailyEntryByDate(userId, today);
      
      if (existingEntry) {
        return res.status(200).json(existingEntry);
      }
      
      // Create a new entry for today
      const newEntry = await storage.createDailyEntry({
        userId,
        date: today,
        silentExecution: {
          task1: { description: "", completed: false },
          task2: { description: "", completed: false },
          task3: { description: "", completed: false },
        },
        strategicPlan: {
          topPriority: "",
          distractions: "",
          smartMove: "",
        },
        purpose: {
          whoFor: "",
          myPurpose: "",
          todayReminder: "",
        },
        dungeonDive: {
          startTime: "",
          endTime: "",
          outcome: "",
        },
        shadowArmy: {
          nameRole: "",
          purpose: "",
          leadOrLearn: "",
        },
        stoicMind: {
          challenges: "",
          response: "",
          improvement: "",
        },
        reflection: {
          wins: "",
          growthAreas: "",
          lessonLearned: "",
        },
      });
      
      // Update user streak when they create a new entry
      await storage.updateUserStreak(userId);
      
      // Add XP for creating a daily entry
      await storage.addUserXP(userId, 10);
      
      return res.status(201).json(newEntry);
    } catch (error) {
      console.error("Error fetching daily entry:", error);
      return res.status(500).json({ message: "Failed to fetch daily entry" });
    }
  });

  // Get a specific daily entry by date
  app.get("/api/daily-entry/:date", async (req: Request, res: Response) => {
    try {
      const userId = 1;
      const date = new Date(req.params.date);
      
      if (isNaN(date.getTime())) {
        return res.status(400).json({ message: "Invalid date format" });
      }
      
      const entry = await storage.getDailyEntryByDate(userId, date);
      
      if (!entry) {
        return res.status(404).json({ message: "Entry not found" });
      }
      
      return res.status(200).json(entry);
    } catch (error) {
      console.error("Error fetching daily entry by date:", error);
      return res.status(500).json({ message: "Failed to fetch daily entry" });
    }
  });

  // Save or update a daily entry
  app.post("/api/daily-entry", async (req: Request, res: Response) => {
    try {
      const userId = 1;
      const entryData = req.body;
      
      // Validate request body
      const validatedData = dailyEntryFormSchema.parse(entryData);
      
      // Check if an entry for today already exists
      const today = new Date();
      const existingEntry = await storage.getDailyEntryByDate(userId, today);
      
      let updatedEntry;
      
      if (existingEntry) {
        // Update existing entry
        updatedEntry = await storage.updateDailyEntry(existingEntry.id, {
          ...validatedData,
          userId,
        });
        
        // Award XP based on how complete the entry is
        const completionXP = calculateCompletionXP(validatedData);
        if (completionXP > 0) {
          await storage.addUserXP(userId, completionXP);
        }
        
        await checkAndAwardBadges(userId, validatedData);
        
        return res.status(200).json(updatedEntry);
      } else {
        // Create new entry
        updatedEntry = await storage.createDailyEntry({
          ...validatedData,
          userId,
          date: today,
        });
        
        // Update streak when creating a new entry
        await storage.updateUserStreak(userId);
        
        // Award XP for creating a daily entry and based on completion
        const completionXP = calculateCompletionXP(validatedData);
        await storage.addUserXP(userId, 10 + completionXP);
        
        await checkAndAwardBadges(userId, validatedData);
        
        return res.status(201).json(updatedEntry);
      }
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      
      console.error("Error saving daily entry:", error);
      return res.status(500).json({ message: "Failed to save daily entry" });
    }
  });

  // Get history of entries
  app.get("/api/daily-entries", async (req: Request, res: Response) => {
    try {
      const userId = 1;
      const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 30;
      
      const entries = await storage.getAllDailyEntriesByUser(userId, limit);
      
      return res.status(200).json(entries);
    } catch (error) {
      console.error("Error fetching daily entries:", error);
      return res.status(500).json({ message: "Failed to fetch daily entries" });
    }
  });
  
  // Get user data (XP, level, streak)
  app.get("/api/user", async (req: Request, res: Response) => {
    try {
      const userId = 1;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Return only necessary info, not password
      const userData = {
        id: user.id,
        username: user.username,
        xp: user.xp,
        level: user.level,
        streakDays: user.streakDays,
        lastCheckIn: user.lastCheckIn
      };
      
      return res.status(200).json(userData);
    } catch (error) {
      console.error("Error fetching user data:", error);
      return res.status(500).json({ message: "Failed to fetch user data" });
    }
  });
  
  // Get badges
  app.get("/api/badges", async (req: Request, res: Response) => {
    try {
      const badges = await storage.getAllBadges();
      return res.status(200).json(badges);
    } catch (error) {
      console.error("Error fetching badges:", error);
      return res.status(500).json({ message: "Failed to fetch badges" });
    }
  });
  
  // Get user badges
  app.get("/api/user/badges", async (req: Request, res: Response) => {
    try {
      const userId = 1;
      const badges = await storage.getUserBadges(userId);
      return res.status(200).json(badges);
    } catch (error) {
      console.error("Error fetching user badges:", error);
      return res.status(500).json({ message: "Failed to fetch user badges" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
