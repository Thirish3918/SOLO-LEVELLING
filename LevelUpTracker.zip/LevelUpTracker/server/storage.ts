import { 
  users, type User, type InsertUser, 
  dailyEntries, type DailyEntry, type InsertDailyEntry,
  badges, type Badge, type InsertBadge,
  userBadges, type UserBadge, type InsertUserBadge
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User | undefined>;
  
  // Daily entries
  getDailyEntry(id: number): Promise<DailyEntry | undefined>;
  getDailyEntryByDate(userId: number, date: Date): Promise<DailyEntry | undefined>;
  createDailyEntry(entry: InsertDailyEntry): Promise<DailyEntry>;
  updateDailyEntry(id: number, entry: Partial<InsertDailyEntry>): Promise<DailyEntry | undefined>;
  getAllDailyEntriesByUser(userId: number, limit?: number): Promise<DailyEntry[]>;
  
  // XP and Streaks
  addUserXP(userId: number, xpAmount: number): Promise<User | undefined>;
  updateUserStreak(userId: number): Promise<User | undefined>;
  resetUserStreak(userId: number): Promise<User | undefined>;
  
  // Badges
  getAllBadges(): Promise<Badge[]>;
  getBadge(id: number): Promise<Badge | undefined>;
  createBadge(badge: InsertBadge): Promise<Badge>;
  getUserBadges(userId: number): Promise<Badge[]>;
  awardBadgeToUser(userId: number, badgeId: number): Promise<UserBadge | undefined>;
  hasBadge(userId: number, badgeId: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private dailyEntries: Map<number, DailyEntry>;
  private badgesList: Map<number, Badge>;
  private userBadgesList: Map<number, UserBadge>;
  private currentUserId: number;
  private currentEntryId: number;
  private currentBadgeId: number;
  private currentUserBadgeId: number;

  constructor() {
    this.users = new Map();
    this.dailyEntries = new Map();
    this.badgesList = new Map();
    this.userBadgesList = new Map();
    this.currentUserId = 1;
    this.currentEntryId = 1;
    this.currentBadgeId = 1;
    this.currentUserBadgeId = 1;
    
    // Add default user
    this.createDefaultUser();
    
    // Initialize default badges
    this.initializeDefaultBadges();
  }
  
  private async createDefaultUser() {
    const defaultUser: User = {
      id: this.currentUserId++,
      username: 'user',
      password: 'password',
      xp: 0,
      level: 1,
      streakDays: 0,
      lastCheckIn: null
    };
    this.users.set(defaultUser.id, defaultUser);
  }
  
  private async initializeDefaultBadges() {
    const defaultBadges: Omit<Badge, 'id'>[] = [
      {
        name: 'Deep Work Beast',
        description: 'Complete 7 consecutive days with at least 2 hours of deep work',
        icon: 'hourglass',
        requirement: 'deepWorkStreak7',
        xpReward: 100
      },
      {
        name: 'Shadow Monarch',
        description: 'Build your network by adding 10 different connections to your Shadow Army',
        icon: 'users',
        requirement: 'shadowArmy10',
        xpReward: 150
      },
      {
        name: 'Task Assassin',
        description: 'Complete all tasks in Silent Execution for 5 consecutive days',
        icon: 'check-circle',
        requirement: 'taskStreak5',
        xpReward: 120
      },
      {
        name: 'Leveling Beast',
        description: 'Reach level 10 through consistent daily check-ins',
        icon: 'bar-chart',
        requirement: 'level10',
        xpReward: 200
      },
      {
        name: 'Growth Master',
        description: 'Log a perfect 10/10 growth rating for 3 consecutive days',
        icon: 'trending-up',
        requirement: 'perfectGrowth3',
        xpReward: 100
      }
    ];
    
    for (const badge of defaultBadges) {
      const id = this.currentBadgeId++;
      this.badgesList.set(id, { ...badge, id });
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id,
      xp: 0,
      level: 1,
      streakDays: 0,
      lastCheckIn: null
    };
    this.users.set(id, user);
    return user;
  }

  async getDailyEntry(id: number): Promise<DailyEntry | undefined> {
    return this.dailyEntries.get(id);
  }

  async getDailyEntryByDate(userId: number, date: Date): Promise<DailyEntry | undefined> {
    const targetDate = new Date(date);
    targetDate.setHours(0, 0, 0, 0);
    
    return Array.from(this.dailyEntries.values()).find(entry => {
      const entryDate = new Date(entry.date);
      entryDate.setHours(0, 0, 0, 0);
      return entry.userId === userId && entryDate.getTime() === targetDate.getTime();
    });
  }

  async createDailyEntry(entryData: InsertDailyEntry): Promise<DailyEntry> {
    const id = this.currentEntryId++;
    const entry: DailyEntry = {
      ...entryData,
      id,
      date: entryData.date || new Date(),
      skillStudied: entryData.skillStudied || null,
      mediaConsumed: entryData.mediaConsumed || null,
      physicalTraining: entryData.physicalTraining || null,
      deepWorkHours: entryData.deepWorkHours || null,
      growthRating: entryData.growthRating || null,
      silentExecution: entryData.silentExecution || {
        task1: { description: "", completed: false },
        task2: { description: "", completed: false },
        task3: { description: "", completed: false },
      },
      strategicPlan: entryData.strategicPlan || {
        topPriority: "",
        distractions: "",
        smartMove: "",
      },
      purpose: entryData.purpose || {
        whoFor: "",
        myPurpose: "",
        todayReminder: "",
      },
      dungeonDive: entryData.dungeonDive || {
        startTime: "",
        endTime: "",
        outcome: "",
      },
      shadowArmy: entryData.shadowArmy || {
        nameRole: "",
        purpose: "",
        leadOrLearn: "",
      },
      stoicMind: entryData.stoicMind || {
        challenges: "",
        response: "",
        improvement: "",
      },
      reflection: entryData.reflection || {
        wins: "",
        growthAreas: "",
        lessonLearned: "",
      },
    };
    this.dailyEntries.set(id, entry);
    return entry;
  }

  async updateDailyEntry(id: number, entryData: Partial<InsertDailyEntry>): Promise<DailyEntry | undefined> {
    const existingEntry = this.dailyEntries.get(id);
    if (!existingEntry) return undefined;

    const updatedEntry: DailyEntry = {
      ...existingEntry,
      ...entryData,
    };

    this.dailyEntries.set(id, updatedEntry);
    return updatedEntry;
  }

  async getAllDailyEntriesByUser(userId: number, limit = 30): Promise<DailyEntry[]> {
    const entries = Array.from(this.dailyEntries.values())
      .filter(entry => entry.userId === userId)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    return entries.slice(0, limit);
  }
  
  // User update methods
  async updateUser(id: number, data: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...data };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // XP and Streaks methods
  async addUserXP(userId: number, xpAmount: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    // Calculate new XP and level
    const newXP = user.xp + xpAmount;
    
    // Simple leveling formula: level up every 100 XP
    const xpPerLevel = 100;
    const newLevel = Math.floor(newXP / xpPerLevel) + 1;
    
    // Update user with new XP and level
    return this.updateUser(userId, { 
      xp: newXP,
      level: newLevel
    });
  }
  
  async updateUserStreak(userId: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    let streakDays = user.streakDays;
    
    // If they have a lastCheckIn date
    if (user.lastCheckIn) {
      const lastCheckDate = new Date(user.lastCheckIn);
      const lastCheckDay = new Date(lastCheckDate.getFullYear(), lastCheckDate.getMonth(), lastCheckDate.getDate());
      
      // Calculate the difference in days
      const diffTime = today.getTime() - lastCheckDay.getTime();
      const diffDays = diffTime / (1000 * 60 * 60 * 24);
      
      // If they checked in yesterday, increase streak
      if (diffDays === 1) {
        streakDays++;
      } 
      // If they checked in today already, maintain streak
      else if (diffDays === 0) {
        // Do nothing, maintain streak
      } 
      // If they missed days, reset streak to 1
      else {
        streakDays = 1;
      }
    } else {
      // First time check-in
      streakDays = 1;
    }
    
    // Update user with new streak and check-in time
    return this.updateUser(userId, {
      streakDays,
      lastCheckIn: now
    });
  }
  
  async resetUserStreak(userId: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    return this.updateUser(userId, {
      streakDays: 0
    });
  }
  
  // Badge methods
  async getAllBadges(): Promise<Badge[]> {
    return Array.from(this.badgesList.values());
  }
  
  async getBadge(id: number): Promise<Badge | undefined> {
    return this.badgesList.get(id);
  }
  
  async createBadge(badge: InsertBadge): Promise<Badge> {
    const id = this.currentBadgeId++;
    const newBadge: Badge = { 
      ...badge, 
      id,
      xpReward: badge.xpReward !== undefined ? badge.xpReward : 0
    };
    this.badgesList.set(id, newBadge);
    return newBadge;
  }
  
  async getUserBadges(userId: number): Promise<Badge[]> {
    // Get all user badge relationships for this user
    const userBadges = Array.from(this.userBadgesList.values())
      .filter(ub => ub.userId === userId);
    
    // Get the actual badge objects
    const badges = userBadges.map(ub => this.badgesList.get(ub.badgeId))
      .filter((badge): badge is Badge => badge !== undefined);
      
    return badges;
  }
  
  async awardBadgeToUser(userId: number, badgeId: number): Promise<UserBadge | undefined> {
    // Check if user and badge exist
    const user = await this.getUser(userId);
    const badge = await this.getBadge(badgeId);
    
    if (!user || !badge) return undefined;
    
    // Check if user already has this badge
    const hasBadge = await this.hasBadge(userId, badgeId);
    if (hasBadge) return undefined;
    
    // Create new user badge relationship
    const id = this.currentUserBadgeId++;
    const userBadge: UserBadge = {
      id,
      userId,
      badgeId,
      earnedAt: new Date()
    };
    
    this.userBadgesList.set(id, userBadge);
    
    // Award XP to the user for earning the badge
    await this.addUserXP(userId, badge.xpReward);
    
    return userBadge;
  }
  
  async hasBadge(userId: number, badgeId: number): Promise<boolean> {
    return Array.from(this.userBadgesList.values())
      .some(ub => ub.userId === userId && ub.badgeId === badgeId);
  }
}

export const storage = new MemStorage();
