import { pgTable, text, serial, integer, timestamp, boolean, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  xp: integer("xp").notNull().default(0),
  level: integer("level").notNull().default(1),
  streakDays: integer("streak_days").notNull().default(0),
  lastCheckIn: timestamp("last_check_in"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Daily entry schema
export const dailyEntries = pgTable("daily_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: timestamp("date").notNull().defaultNow(),
  
  // Daily Stats
  skillStudied: text("skill_studied"),
  mediaConsumed: text("media_consumed"),
  physicalTraining: text("physical_training"),
  deepWorkHours: integer("deep_work_hours"),
  growthRating: integer("growth_rating"),
  
  // Silent Execution
  silentExecution: json("silent_execution").$type<{
    task1: { description: string; completed: boolean };
    task2: { description: string; completed: boolean };
    task3: { description: string; completed: boolean };
  }>(),
  
  // Strategic Strike Plan
  strategicPlan: json("strategic_plan").$type<{
    topPriority: string;
    distractions: string;
    smartMove: string;
  }>(),
  
  // Purpose Lock-in
  purpose: json("purpose").$type<{
    whoFor: string;
    myPurpose: string;
    todayReminder: string;
  }>(),
  
  // Dungeon Dive
  dungeonDive: json("dungeon_dive").$type<{
    startTime: string;
    endTime: string;
    outcome: string;
  }>(),
  
  // Shadow Army
  shadowArmy: json("shadow_army").$type<{
    nameRole: string;
    purpose: string;
    leadOrLearn: string;
  }>(),
  
  // Stoic Mind Training
  stoicMind: json("stoic_mind").$type<{
    challenges: string;
    response: string;
    improvement: string;
  }>(),
  
  // End of Day Reflection
  reflection: json("reflection").$type<{
    wins: string;
    growthAreas: string;
    lessonLearned: string;
  }>(),
});

export const insertDailyEntrySchema = createInsertSchema(dailyEntries).omit({
  id: true,
});

// Form validation schema for daily entry
export const dailyEntryFormSchema = z.object({
  // Daily Stats
  skillStudied: z.string().optional(),
  mediaConsumed: z.string().optional(),
  physicalTraining: z.string().optional(),
  deepWorkHours: z.number().min(0).max(24).optional(),
  growthRating: z.number().min(1).max(10).optional(),
  
  // Silent Execution
  silentExecution: z.object({
    task1: z.object({
      description: z.string().optional(),
      completed: z.boolean().default(false),
    }),
    task2: z.object({
      description: z.string().optional(),
      completed: z.boolean().default(false),
    }),
    task3: z.object({
      description: z.string().optional(),
      completed: z.boolean().default(false),
    }),
  }),
  
  // Strategic Strike Plan
  strategicPlan: z.object({
    topPriority: z.string().optional(),
    distractions: z.string().optional(),
    smartMove: z.string().optional(),
  }),
  
  // Purpose Lock-in
  purpose: z.object({
    whoFor: z.string().optional(),
    myPurpose: z.string().optional(),
    todayReminder: z.string().optional(),
  }),
  
  // Dungeon Dive
  dungeonDive: z.object({
    startTime: z.string().optional(),
    endTime: z.string().optional(),
    outcome: z.string().optional(),
  }),
  
  // Shadow Army
  shadowArmy: z.object({
    nameRole: z.string().optional(),
    purpose: z.string().optional(),
    leadOrLearn: z.string().optional(),
  }),
  
  // Stoic Mind Training
  stoicMind: z.object({
    challenges: z.string().optional(),
    response: z.string().optional(),
    improvement: z.string().optional(),
  }),
  
  // End of Day Reflection
  reflection: z.object({
    wins: z.string().optional(),
    growthAreas: z.string().optional(),
    lessonLearned: z.string().optional(),
  }),
});

// Badges system
export const badges = pgTable("badges", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  requirement: text("requirement").notNull(),
  xpReward: integer("xp_reward").notNull().default(0),
});

export const userBadges = pgTable("user_badges", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  badgeId: integer("badge_id").notNull(),
  earnedAt: timestamp("earned_at").notNull().defaultNow(),
});

export const insertBadgeSchema = createInsertSchema(badges).omit({
  id: true,
});

export const insertUserBadgeSchema = createInsertSchema(userBadges).omit({
  id: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type DailyEntry = typeof dailyEntries.$inferSelect;
export type InsertDailyEntry = z.infer<typeof insertDailyEntrySchema>;
export type DailyEntryForm = z.infer<typeof dailyEntryFormSchema>;
export type Badge = typeof badges.$inferSelect;
export type InsertBadge = z.infer<typeof insertBadgeSchema>;
export type UserBadge = typeof userBadges.$inferSelect;
export type InsertUserBadge = z.infer<typeof insertUserBadgeSchema>;
